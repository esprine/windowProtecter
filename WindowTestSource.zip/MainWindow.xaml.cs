﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace WindowTest
{
	/// <summary>
	/// MainWindow.xaml에 대한 상호 작용 논리
	/// </summary>
	public partial class MainWindow : Window
	{
		// 비밀번호 설정
		private string psdwrd = string.Empty;
		private bool isClose = false;
        static readonly HttpClient httpClient = new HttpClient();

        [Obsolete]
        public MainWindow()
		{
			InitializeComponent();

            ApplyOutlineText(Label1, Brushes.Black);
            ApplyOutlineText(Label2, Brushes.Black);

            /*
            // 테스트
            // //*[@id="container"]/div[2]/table
            string url = "https://df.nexon.com/df/news/notice";
            using (IWebDriver driver = new ChromeDriver())
            {
                driver.Url = url;
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2);

                var elements = driver.FindElements(By.XPath("//*[@id=\"container\"]/div[2]/table/tbody"));
                string txt = string.Empty;

                foreach (var el in elements)
                {
                    List<string> list = new List<string>();
                    for (int i = 1; i <= 20; i++)
                    {
                        // 각각의 li 에서 원하는 데이터를 찾는다. span tag 중 class 명이 main_title 인 element
                        var title = el.FindElement(By.XPath("//*[@id=\"container\"]/div[2]/table/tbody/tr[" + i.ToString() + "]")).Text.Trim();
                        list.Add(title);
                    }

                    DateTime dateToday = DateTime.Today;
                    DateTime thursDate = dateToday.AddDays(Convert.ToInt32(DayOfWeek.Thursday) - Convert.ToInt32(dateToday.DayOfWeek));

                    int day = thursDate.Day;
                    int month = thursDate.Month;
                    string monthDay = month.ToString() + "/" + day.ToString();
                    if (list.Where(o => o.Contains("정기점검") && o.Contains(monthDay)).Count() == 0)
                    {
                        MessageBox.Show("점검 공지가 없습니다.");
                    }
                    else
                    {
                        MessageBox.Show(monthDay + " 점검 공지가 있습니다.");
                    }
                        
                }
            }
            */
            // Thread updateChecker = new Thread(CheckUpdate);
        }

        public static void CheckUpdate()
        {
            // 업데이트 체크

            // 10800000ms = 3h
            Thread.Sleep(10800000);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        static async Task Test(string url, string txt)
        {
            try
            {
                using (var response = await httpClient.GetAsync(url, HttpCompletionOption.ResponseHeadersRead))
                {
                    Console.WriteLine(response.StatusCode);

                    if (HttpStatusCode.OK == response.StatusCode)
                    {
                        string body = await response.Content.ReadAsStringAsync();
                        
                        Console.WriteLine(body);
                        txt = body;
                    }
                    else
                    {
                        Console.WriteLine($" -- response.ReasonPhrase ==> {response.ReasonPhrase}");
                    }
                }

            }
            catch (HttpRequestException ex)
            {
                Console.WriteLine($"ex.Message={ex.Message}");
                Console.WriteLine($"ex.InnerException.Message = {ex.InnerException.Message}");

                Console.WriteLine($"----------- 서버에 연결할수없습니다 ---------------------");
            }
            catch (Exception ex2)
            {
                Console.WriteLine($"Exception={ex2.Message}");
            }
        }

        /// <summary>
        /// popupSetting의 Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void btnSubmit_Click1(object sender, RoutedEventArgs e)
		{
			if (txtPassword1.Password.Length >= 8)
            {
                popupSetting.IsOpen = false;
                popupPwd.IsOpen = true;
                psdwrd = txtPassword1.Password;
            }
            else
            {
                System.Windows.MessageBox.Show("8자리 이상의 비밀번호를 입력해주세요.");
                txtPassword1.Password = string.Empty;
            }
        }

        /// <summary>
        /// popupPwd의 Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSubmit_Click2(object sender, RoutedEventArgs e)
        {
            if (txtPassword2.Password.Equals(psdwrd))
            {
                isClose = true;
                psdwrd = string.Empty;
                this.Close();
            }
            else
            {
                System.Windows.MessageBox.Show("입력한 비밀번호는 설정된 비밀번호와 다릅니다.");
                txtPassword2.Password = string.Empty;
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
            if (isClose == false)
            {
                e.Cancel = true;
            }
            else
            {
                foreach (Process process in Process.GetProcesses())
                {
                    if (process.ProcessName.Contains("chromedriver") || process.ProcessName.Contains("Google Chrome"))
                        process.Kill();
                }
            }
		}

        private void Window_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
			if (e.Key == Key.F12)
			{
				isClose = true;
                psdwrd = string.Empty;
				this.Close();
			}
        }

        /// <summary>
        /// popupSetting의 Enter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtPassword_PreviewKeyDown1(object sender, System.Windows.Input.KeyEventArgs e)
        {
			if (e.Key == Key.Enter)
			{
				if (txtPassword1.Password.Length > 0)
				{
					btnSubmit_Click1(sender, new RoutedEventArgs());
				}
			}
        }

        /// <summary>
        /// popupPwd의 Enter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtPassword_PreviewKeyDown2(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (txtPassword2.Password.Length > 0)
                {
                    btnSubmit_Click2(sender, new RoutedEventArgs());
                }
            }
        }

        /*
		private void Window_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			if (e.Key == Key.LeftAlt || e.Key == Key.F4 || e.Key == Key.LeftCtrl || e.Key == Key.LWin || e.Key == Key.RWin) { e.Handled = true; }

			
            if (e.Key == Key.LeftAlt && e.Key == Key.F4) { e.Handled = true; }
            if (e.Key == Key.LeftAlt && e.Key == Key.Tab) { e.Handled = true; }
            if (e.Key == Key.LeftCtrl && e.Key == Key.LeftAlt && e.Key == Key.Delete) { e.Handled = true; }
            if (e.Key == Key.LWin || e.Key == Key.RWin) { e.Handled = true; }
			

            if (e.Key == Key.Decimal) { e.Handled = false; }
        }
		*/

        #region 윤곽선 텍스트 적용하기 - ApplyOutlineText(label, outlineBrush)

        /// <summary>
        /// 윤곽선 텍스트 적용하기
        /// </summary>
        /// <param name="label">레이블</param>
        /// <param name="outlineBrush">외곽선 브러시</param>
        [Obsolete]
        private void ApplyOutlineText(Label label, Brush outlineBrush)
        {
            label.FontSize = 102;
            label.FontWeight = FontWeights.Bold;
            label.Foreground = Brushes.White;

            FormattedText formattedText = new FormattedText
            (
                label.Content.ToString(),
                System.Threading.Thread.CurrentThread.CurrentCulture,
                FlowDirection,
                new Typeface(label.FontFamily, label.FontStyle, label.FontWeight, label.FontStretch),
                label.FontSize,
                Brushes.Black
            );

            formattedText.TextAlignment = TextAlignment.Center;

            Geometry geometry = formattedText.BuildGeometry(new Point(0, 0));

            PathGeometry pathGeometry = geometry.GetFlattenedPathGeometry();

            Path path = new Path();

            path.Stroke = outlineBrush;
            path.StrokeThickness = 5;
            path.Fill = label.Foreground;
            path.Stretch = Stretch.Fill;

            Canvas canvas = new Canvas();

            canvas.Children.Add(path);

            label.Content = canvas;

            Canvas.SetTop(path, (canvas.ActualHeight - formattedText.Extent) / 2);
            Canvas.SetLeft(path, (canvas.ActualWidth - formattedText.Width) / 2);

            path.Data = pathGeometry;
        }

        #endregion
    }
}
